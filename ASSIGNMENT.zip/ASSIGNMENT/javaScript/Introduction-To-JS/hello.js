// document.body.innerHTML = "HelloWorld<br>";
document.write("HelloWorld");
