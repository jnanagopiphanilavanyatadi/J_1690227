let txt = prompt("Enter text containing the word 'World' :");
document.write("Entered text : " + txt + "<br>");
let pos = txt.indexOf("World");
document.write("Position of 'World' in text : " + pos);
